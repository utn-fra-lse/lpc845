Hardware requirements
=====================
- Micro USB cable
- LPC845 Breakout board
- Personal Computer

